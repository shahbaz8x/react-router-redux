import '../../App.css';

function Staff() {
  return (
    <div>
        <h5>Staff</h5>
        <p>Our Staff.</p>
    </div>
  );
}

export default Staff;
