import { Container, Row, Col } from 'react-bootstrap';

function Header() {

    return (
        <Container className="bg-warning" fluid>
            <Container>
                <Row>
                    <Col>
                        <h1>Header</h1>
                    </Col>
                </Row>
            </Container>
        </Container>
        
    );
}


export default Header;