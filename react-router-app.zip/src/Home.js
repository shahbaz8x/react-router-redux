import { Container, Row, Col } from 'react-bootstrap';

function Home() {

    return (
        <Container className="bg-info" fluid>
            <Container>
                <Row>
                    <Col>
                        <h1>Home</h1>
                    </Col>
                </Row>
            </Container>
        </Container>
        
    );
}


export default Home;