import '../App.css';
import { Container, Row, Col } from 'react-bootstrap';

function Staff() {
  return (
    <Container>
      <Row>
        <Col sm={12}>Staff Page</Col>
      </Row>
    </Container>
  );
}

export default Staff;
