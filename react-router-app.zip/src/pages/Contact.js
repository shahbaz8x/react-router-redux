import '../App.css';
import { Container, Row, Col, Breadcrumb } from 'react-bootstrap';

function Contact() {
  return (
    <Container>
      <Breadcrumb>
      <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
      <Breadcrumb.Item href="/about">
        About
      </Breadcrumb.Item>
      <Breadcrumb.Item active>Contact</Breadcrumb.Item>
    </Breadcrumb>

      <Row>
        <Col sm={12}>Contact us at aayesha.com@gmail.com</Col>
      </Row>
    </Container>
  );
}

export default Contact;
